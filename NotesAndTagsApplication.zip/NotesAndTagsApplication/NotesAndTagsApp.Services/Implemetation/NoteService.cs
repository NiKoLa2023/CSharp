﻿using NotesAndTags.DTOs;
using NotesAndTagsApp.DataAccess.Implementation;
using NotesAndTagsApp.DataAccess.Interfaces;
using NotesAndTagsApp.Services.Interfaces;
using NotesAndTAgsApp.Domain.Models;
using NotesAndTagsApp.Mappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotesAndTagsApp.Services.Implemetation
{
    public class NoteService : INoteService
    {
        private readonly IRepository<Note> _noteRepository;

        public NoteService(IRepository<Note> noteRepository)
        {
            _noteRepository = noteRepository;
        }
        
        public List<NoteDto> GetAllNotes()
        {
            var notesDb = _noteRepository.GetAll(); 

      
            return notesDb.Select(x => x.ToNoteDto()).ToList();
            
        }
    }
}
    