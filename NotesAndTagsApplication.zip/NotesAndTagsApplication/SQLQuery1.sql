INSERT INTO Users (FirstName, LastName, Username)
VALUES ('Nikolas', 'Dimitrovski', 'Myname')

SELECT *
FROM Users

INSERT INTO Notes(Text, Priority, Tag, UserId)
VALUES ('Shopping', '1', '1', '2')