﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotesAndTAgsApp.Domain.Enums
{
    public enum PriorityEnum
    {
        Low = 1,
        Medium = 2,
        High
    }
}
